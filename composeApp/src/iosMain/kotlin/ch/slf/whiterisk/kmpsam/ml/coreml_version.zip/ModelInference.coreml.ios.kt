package ch.slf.whiterisk.multiplatform.domain.conditions.ml

import kotlinx.cinterop.*
import platform.Foundation.*
import platform.CoreML.*
import platform.darwin.NSInteger
import platform.darwin.NSUInteger

/**
 * iOS implementation of ModelInference using Core ML.
 */
@OptIn(ExperimentalForeignApi::class)
actual class ModelInference {

    private var model: MLModel? = null

    // Store input and output metadata
    private val inputNames = mutableListOf<String>()
    private val outputNames = mutableListOf<String>()

    companion object {
        private const val TAG = "ModelInference.iOS"

        private fun log(message: String) {
            println("[$TAG] $message")
        }

        private fun logError(message: String, error: Throwable? = null) {
            println("[$TAG] ERROR: $message")
            error?.let { println("  ${it.message}") }
        }

        // Constants for FP16 conversions
        private const val FP32_SIGN_SHIFT = 31
        private const val FP32_EXPONENT_SHIFT = 23
        private const val FP32_SHIFTED_EXPONENT_MASK = 0xff
        private const val FP32_SIGNIFICAND_MASK = 0x7fffff
        private const val FP32_EXPONENT_BIAS = 127
        private const val FP32_QNAN_MASK = 0x400000
        private const val FP32_DENORMAL_MAGIC = 126 shl 23
        private val FP32_DENORMAL_FLOAT = Float.fromBits(FP32_DENORMAL_MAGIC)

        private const val SIGN_MASK = 0x8000
        private const val EXPONENT_SHIFT = 10
        private const val SHIFTED_EXPONENT_MASK = 0x1f
        private const val SIGNIFICAND_MASK = 0x3ff
        private const val EXPONENT_BIAS = 15

        fun toFloat(h: Short): Float {
            val bits = h.toInt() and 0xffff
            val s = bits and SIGN_MASK
            var e = (bits ushr EXPONENT_SHIFT) and SHIFTED_EXPONENT_MASK
            var m = bits and SIGNIFICAND_MASK
            var outE = 0
            var outM = 0
            if (e == 0) { // Denormal or 0
                if (m != 0) {
                    // Convert denorm fp16 into normalized fp32
                    var o = Float.fromBits(FP32_DENORMAL_MAGIC + m)
                    o -= FP32_DENORMAL_FLOAT
                    return if (s == 0) o else -o
                }
            } else {
                outM = m shl 13
                if (e == 0x1f) { // Infinite or NaN
                    outE = 0xff
                    if (outM != 0) { // SNaNs are quieted
                        outM = outM or FP32_QNAN_MASK
                    }
                } else {
                    outE = e - EXPONENT_BIAS + FP32_EXPONENT_BIAS
                }
            }
            val out = (s shl 16) or (outE shl FP32_EXPONENT_SHIFT) or outM
            return Float.fromBits(out)
        }

        fun toHalf(f: Float): Short {
            val bits = f.toRawBits()
            val s = (bits ushr FP32_SIGN_SHIFT)
            var e = (bits ushr FP32_EXPONENT_SHIFT) and FP32_SHIFTED_EXPONENT_MASK
            var m = bits and FP32_SIGNIFICAND_MASK
            var outE = 0
            var outM = 0
            if (e == 0xff) { // Infinite or NaN
                outE = 0x1f
                outM = if (m != 0) 0x200 else 0
            } else {
                e = e - FP32_EXPONENT_BIAS + EXPONENT_BIAS
                if (e >= 0x1f) { // Overflow
                    outE = 0x1f
                } else if (e <= 0) { // Underflow
                    if (e < -10) {
                        // The absolute fp32 value is less than MIN_VALUE, flush to +/-0
                    } else {
                        // The fp32 value is a normalized float less than MIN_NORMAL,
                        // we convert to a denorm fp16
                        m = m or 0x800000
                        val shift = 14 - e
                        outM = m ushr shift
                        val lowm = m and ((1 shl shift) - 1)
                        val hway = 1 shl (shift - 1)
                        // if above halfway or exactly halfway and outM is odd
                        if (lowm + (outM and 1) > hway) {
                            // Round to nearest even
                            // Can overflow into exponent bit, which surprisingly is OK.
                            // This increment relies on the +outM in the return statement below
                            outM++
                        }
                    }
                } else {
                    outE = e
                    outM = m ushr 13
                    // if above halfway or exactly halfway and outM is odd
                    if ((m and 0x1fff) + (outM and 0x1) > 0x1000) {
                        // Round to nearest even
                        // Can overflow into exponent bit, which surprisingly is OK.
                        // This increment relies on the +outM in the return statement below
                        outM++
                    }
                }
            }
            // The outM is added here as the +1 increments for outM above can
            // cause an overflow in the exponent bit which is OK.
            return ((s shl EXPONENT_SHIFT + 5) or (outE shl EXPONENT_SHIFT) + outM).toShort()
        }
    }

    /**
     * Loads the Core ML model from the specified path.
     */
    actual fun loadModel(modelPath: String) {
        try {
            log("Loading model from: $modelPath")

            // Assume modelPath is relative to resources, e.g., "models/SAM2_1TinyImageEncoderFLOAT16.mlpackage"
            val resourceURL = NSBundle.mainBundle.resourceURL ?: throw IllegalStateException("Resource URL not found")
            val modelURL = resourceURL.URLByAppendingPathComponent(modelPath)
                ?: throw IllegalStateException("Model URL not found for path: $modelPath")

            memScoped {
                val errorPtr = alloc<ObjCObjectVar<NSError?>>()
                model = MLModel.modelWithContentsOfURL(modelURL, errorPtr.ptr)

                errorPtr.value?.let { error ->
                    throw Exception("Failed to load Core ML model: ${error.localizedDescription}")
                }
            }

            val currentModel = model ?: throw Exception("Model not loaded")

            // Get input names
            val inputDescs = currentModel.modelDescription?.inputDescriptionsByName
                ?: throw Exception("Model description not available")
            inputNames.addAll(inputDescs.keys.map { it as String })

            // Get output names
            val outputDescs = currentModel.modelDescription?.outputDescriptionsByName
                ?: throw Exception("Model description not available")
            outputNames.addAll(outputDescs.keys.map { it as String })

            log("✓ Model loaded successfully")
            log("Model has ${inputNames.size} input(s):")
            inputNames.forEach { log("  • Input: '$it'") }
            log("Model has ${outputNames.size} output(s):")
            outputNames.forEach { log("  • Output: '$it'") }

        } catch (e: Exception) {
            logError("Failed to load model from $modelPath", e)
            close()
            throw Exception("Failed to load Core ML model from $modelPath: ${e.message}", e)
        }
    }

    actual fun runInference(input: FloatArray, inputShape: IntArray): Map<String, FloatArray> {
        val currentModel = model
            ?: throw Exception("Model not loaded. Call loadModel() first.")

        try {
            log("Running single-input inference")
            log("  Input data size: ${input.size}")
            log("  Input shape: ${inputShape.contentToString()}")

            val inputName = inputNames.firstOrNull()
                ?: throw Exception("Model has no inputs defined")

            log("  Input name: '$inputName'")

            val inputsMap = mapOf(inputName to Pair(input, inputShape))
            return runInferenceMultiInput(inputsMap)

        } catch (e: Exception) {
            logError("Inference failed", e)
            throw Exception("Failed to run inference: ${e.message}", e)
        }
    }

    actual fun runInferenceMultiInput(inputs: Map<String, Pair<FloatArray, IntArray>>): Map<String, FloatArray> {
        val currentModel = model
            ?: throw Exception("Model not loaded. Call loadModel() first.")

        val modelDescription = currentModel.modelDescription
            ?: throw Exception("Model description not available")

        val inputDescs = modelDescription.inputDescriptionsByName

        try {
            log("Running multi-input inference")
            log("  Number of inputs: ${inputs.size}")

            memScoped {
                val errorPtr = alloc<ObjCObjectVar<NSError?>>()

                val featureDict = mutableMapOf<Any?, Any?>()

                for ((name, dataAndShape) in inputs) {
                    val (data, shape) = dataAndShape
                    log("  Creating input '$name': shape=${shape.contentToString()}, data size=${data.size}")

                    val desc = inputDescs[name as Any?] as? MLFeatureDescription
                        ?: throw Exception("Input description not found for '$name'")

                    val constraint = desc.multiArrayConstraint
                        ?: throw Exception("Input '$name' is not a multi-array")

                    val dataType = constraint.dataType

                    val shapeList: List<NSNumber> = shape.map { NSNumber(long = it.toLong()) }

                    val multiArray = MLMultiArray(
                        shapeList as NSCoder,
                        // dataType,
                        // errorPtr.ptr
                    ) ?: throw Exception("Failed to create MLMultiArray for '$name': ${errorPtr.value?.localizedDescription}")

//                    val multiArr = MLMultiArray()
//                    multiArr.da

                    val elementCount = data.size

                    when (dataType) {
                        MLMultiArrayDataTypeFloat32, MLMultiArrayDataTypeFloat16 -> {
                            for (i in 0 until elementCount) {
                                multiArray.setObject(
                                    NSNumber(double = data[i].toDouble()),
                                    atIndexedSubscript = i.toLong()
                                )
                            }
                        }
                        MLMultiArrayDataTypeInt32 -> {
                            for (i in 0 until elementCount) {
                                multiArray.setObject(
                                    NSNumber(long = data[i].toLong()),
                                    atIndexedSubscript = i.toLong()
                                )
                            }
                        }
                        else -> throw Exception("Unsupported data type for input '$name': $dataType")
                    }

                    val featureValue = MLFeatureValue.featureValueWithMultiArray(multiArray)
                        ?: throw Exception("Failed to create feature value for '$name'")

                    featureDict[name as Any?] = featureValue
                }

                val inputProvider = MLDictionaryFeatureProvider(
                    dictionary = featureDict,
                    error = errorPtr.ptr
                ) ?: throw Exception("Failed to create input provider: ${errorPtr.value?.localizedDescription}")

                log("  Running model...")
                val options = MLPredictionOptions()
                val prediction = currentModel.predictionFromFeatures(
                    input = inputProvider,
                    options = options,
                    error = errorPtr.ptr
                ) ?: throw Exception("Prediction failed: ${errorPtr.value?.localizedDescription}")

                val outputs = mutableMapOf<String, FloatArray>()

                for (outputName in outputNames) {
                    val feature = prediction.featureValueForName(outputName)
                        ?: continue

                    if (feature.type == MLFeatureTypeMultiArray) {
                        val outArray = feature.multiArrayValue
                            ?: continue

                        val outDataType = outArray.dataType

                        val shape = outArray.shape.map { (it as NSNumber).longValue.toInt() }
                        var elementCount = 1
                        shape.forEach { dim: Int -> elementCount *= dim }

                        val outFloat = FloatArray(elementCount)

                        when (outDataType) {
                            MLMultiArrayDataTypeFloat32, MLMultiArrayDataTypeFloat16 -> {
                                for (i in 0 until elementCount) {
                                    val num = outArray.objectAtIndexedSubscript(i.toLong()) as? NSNumber
                                    outFloat[i] = num?.floatValue ?: 0f
                                }
                            }
                            else -> {
                                log("  ⚠ Unsupported output data type for '$outputName': $outDataType")
                                continue
                            }
                        }

                        log("  ✓ Extracted ${outFloat.size} floats from '$outputName'")
                        outputs[outputName] = outFloat
                    }
                }

                if (outputs.isEmpty()) {
                    throw Exception("No float tensor outputs extracted")
                }

                log("  ✓ Inference complete, got ${outputs.size} output(s)")

                return outputs
            }

        } catch (e: Exception) {
            logError("Multi-input inference failed", e)
            throw Exception("Failed to run multi-input inference: ${e.message}", e)
        }
    }

    actual fun close() {
        log("Closing model")
        model = null
        inputNames.clear()
        outputNames.clear()
    }
}